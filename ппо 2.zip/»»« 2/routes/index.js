var express = require('express');
var router = express.Router();
var fs=require("fs")

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/newUser', function(req, res, next) {
  res.render('NewUser.hbs', {
     a1: req.query.imia,
     a2: req.query.clas,
     a3: req.query.kurs,
    });
});

module.exports = router;
